﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MARKETTAKIPSISTEMI
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        void Listele()
        {
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Urunler", Veritabani.baglanti);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgvUrun.DataSource = dt;
        }
        private void btnListele_Click(object sender, EventArgs e)
        {
            Listele();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            try
            {
                Veritabani.Baglan();

                double fiyat = Convert.ToDouble(txtFiyat.Text);
                int stok = Convert.ToInt32(txtStok.Text);

                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Urunler(UrunAdi,Fiyat,Stok) VALUES(@a,@f,@s)",
                    Veritabani.baglanti);

                cmd.Parameters.AddWithValue("@a", txtAd.Text);
                cmd.Parameters.AddWithValue("@f", fiyat);
                cmd.Parameters.AddWithValue("@s", stok);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Ürün eklendi ✅");

                Listele();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            Veritabani.Baglan();

            int id = Convert.ToInt32(dgvUrun.CurrentRow.Cells[0].Value);

            SqlCommand cmd = new SqlCommand(
                "DELETE FROM Urunler WHERE Id=@id",
                Veritabani.baglanti);

            cmd.Parameters.AddWithValue("@id", id);

            cmd.ExecuteNonQuery();

            MessageBox.Show("Silindi ❌");
            Listele();
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            Veritabani.Baglan();

            int id = Convert.ToInt32(dgvUrun.CurrentRow.Cells[0].Value);

            SqlCommand cmd = new SqlCommand(
                "UPDATE Urunler SET UrunAdi=@a, Fiyat=@f, Stok=@s WHERE Id=@id",
                Veritabani.baglanti);

            cmd.Parameters.AddWithValue("@a", txtAd.Text);
            cmd.Parameters.AddWithValue("@f", Convert.ToDouble(txtFiyat.Text));
            cmd.Parameters.AddWithValue("@s", Convert.ToInt32(txtStok.Text));
            cmd.Parameters.AddWithValue("@id", id);

            cmd.ExecuteNonQuery();

            MessageBox.Show("Güncellendi 🔄");
            Listele();
        }

        private void btnGeriDon_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();

            this.Close();
        }
    }
}
