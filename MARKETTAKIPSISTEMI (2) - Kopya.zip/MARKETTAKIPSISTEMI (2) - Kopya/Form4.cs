﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MARKETTAKIPSISTEMI
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        void Listele()
        {
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Musteriler", Veritabani.baglanti);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgvMusteri.DataSource = dt;
        }
        private void btnListele_Click(object sender, EventArgs e)
        {
            Listele();
        }
        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            Veritabani.Baglan();

            SqlCommand cmd = new SqlCommand(
                "INSERT INTO Musteriler(AdSoyad,Telefon) VALUES(@a,@t)",
                Veritabani.baglanti);

            cmd.Parameters.AddWithValue("@a", txtAdSoyad.Text);
            cmd.Parameters.AddWithValue("@t", txtTelefon.Text);

            cmd.ExecuteNonQuery();

            MessageBox.Show("Müşteri eklendi");
            Listele();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            Veritabani.Baglan();

            int id = Convert.ToInt32(dgvMusteri.CurrentRow.Cells[0].Value);

            SqlCommand cmd = new SqlCommand(
                "DELETE FROM Musteriler WHERE Id=@id",
                Veritabani.baglanti);

            cmd.Parameters.AddWithValue("@id", id);

            cmd.ExecuteNonQuery();

            MessageBox.Show("Müşteri silindi ❌");
            Listele();
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            Veritabani.Baglan();

            int id = Convert.ToInt32(dgvMusteri.CurrentRow.Cells[0].Value);

            SqlCommand cmd = new SqlCommand(
                "UPDATE Musteriler SET AdSoyad=@a,Telefon=@t WHERE Id=@id",
                Veritabani.baglanti);

            cmd.Parameters.AddWithValue("@a", txtAdSoyad.Text);
            cmd.Parameters.AddWithValue("@t", txtTelefon.Text);
            cmd.Parameters.AddWithValue("@id", id);

            cmd.ExecuteNonQuery();

            MessageBox.Show("Güncellendi");
            Listele();
        }

        private void btnGeriDon_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();

            this.Close();

        }
    }
}
