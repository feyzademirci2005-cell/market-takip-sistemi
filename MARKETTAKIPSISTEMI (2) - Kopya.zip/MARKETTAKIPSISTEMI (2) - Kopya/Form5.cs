﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MARKETTAKIPSISTEMI
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        void SatisListele()
        {
            Veritabani.Baglan();

            SqlDataAdapter da = new SqlDataAdapter(@"
        SELECT 
        S.Id,
        U.UrunAdi,
        M.AdSoyad,
        S.Adet,
        S.ToplamFiyat
    FROM Satislar S
    INNER JOIN Urunler U ON S.UrunId = U.Id
    INNER JOIN Musteriler M ON S.MusteriId = M.Id",
            Veritabani.baglanti);

            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;
        }
        void KasaHesapla()
        {
            Veritabani.Baglan();

            SqlCommand cmd = new SqlCommand(
                "SELECT SUM(ToplamFiyat) FROM Satislar",
                Veritabani.baglanti);

            object sonuc = cmd.ExecuteScalar();

            if (sonuc != DBNull.Value)
                lblKasa.Text = sonuc.ToString() + " TL";
            else
                lblKasa.Text = "0 TL";
        }
        private void btnSatisYap_Click(object sender, EventArgs e)
        {

        }
        private void Form5_Load(object sender, EventArgs e)
        {
            
        
            Veritabani.Baglan();

            // ÜRÜNLER
            SqlCommand cmd1 = new SqlCommand(
    "SELECT * FROM Urunler WHERE Stok > 0",Veritabani.baglanti);
            SqlDataReader dr1 = cmd1.ExecuteReader();

            while (dr1.Read())
            {
                cmbUrunler.Items.Add(dr1["UrunAdi"].ToString());
            }

            dr1.Close(); 

            // MÜŞTERİLER
            SqlCommand cmd2 = new SqlCommand("SELECT * FROM Musteriler", Veritabani.baglanti);
            SqlDataReader dr2 = cmd2.ExecuteReader();

            while (dr2.Read())
            {
                cmbMusteriler.Items.Add(dr2["AdSoyad"].ToString());
            }

            dr2.Close();
            SatisListele();
            KasaHesapla();


        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtAdet_TextChanged(object sender, EventArgs e)
        {
            if (cmbUrunler.SelectedItem == null) return;

            Veritabani.Baglan();

            SqlCommand cmd = new SqlCommand(
                "SELECT Fiyat FROM Urunler WHERE UrunAdi=@ad",
                Veritabani.baglanti);

            cmd.Parameters.AddWithValue("@ad", cmbUrunler.SelectedItem.ToString());

            object fiyat = cmd.ExecuteScalar();

            if (fiyat != null && txtAdet.Text != "")
            {
                double f = Convert.ToDouble(fiyat);
                int adet = Convert.ToInt32(txtAdet.Text);

                txtToplam.Text = (f * adet).ToString();
            }
        }

        private void btnSatışYap_Click(object sender, EventArgs e)
        {
            try
            {
                Veritabani.Baglan();

                // ÜRÜN ID
                SqlCommand cmd1 = new SqlCommand(
                    "SELECT Id FROM Urunler WHERE UrunAdi=@ad",
                    Veritabani.baglanti);
                cmd1.Parameters.AddWithValue("@ad", cmbUrunler.Text);
                int urunId = Convert.ToInt32(cmd1.ExecuteScalar());

                // MÜŞTERİ ID
                SqlCommand cmd2 = new SqlCommand(
                    "SELECT Id FROM Musteriler WHERE AdSoyad=@ad",
                    Veritabani.baglanti);
                cmd2.Parameters.AddWithValue("@ad", cmbMusteriler.Text);
                int musteriId = Convert.ToInt32(cmd2.ExecuteScalar());

                // 🔥 STOK KONTROL BURADA
                SqlCommand stokKontrol = new SqlCommand(
                    "SELECT Stok FROM Urunler WHERE Id=@id",
                    Veritabani.baglanti);

                stokKontrol.Parameters.AddWithValue("@id", urunId);

                int stok = Convert.ToInt32(stokKontrol.ExecuteScalar());
                int adet = Convert.ToInt32(txtAdet.Text);

                if (stok < adet)
                {
                    MessageBox.Show("Yetersiz stok! ❌");
                    return;
                }

                // SATIŞ EKLE
                SqlCommand cmd3 = new SqlCommand(
                    "INSERT INTO Satislar(UrunId,MusteriId,Adet,ToplamFiyat) VALUES(@u,@m,@a,@t)",
                    Veritabani.baglanti);

                cmd3.Parameters.AddWithValue("@u", urunId);
                cmd3.Parameters.AddWithValue("@m", musteriId);
                cmd3.Parameters.AddWithValue("@a", Convert.ToInt32(txtAdet.Text));
                cmd3.Parameters.AddWithValue("@t", Convert.ToDouble(txtToplam.Text));

                cmd3.ExecuteNonQuery();
                // 🔥 STOK DÜŞME BURAYA
                SqlCommand stokDus = new SqlCommand(
                    "UPDATE Urunler SET Stok = Stok - @adet WHERE Id=@id",
                    Veritabani.baglanti);

                stokDus.Parameters.AddWithValue("@adet", Convert.ToInt32(txtAdet.Text));
                stokDus.Parameters.AddWithValue("@id", urunId);

                stokDus.ExecuteNonQuery();

                MessageBox.Show("Satış yapıldı 🔥");
                KasaHesapla();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnGeriDon_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();

            this.Close();

        }
    }
}