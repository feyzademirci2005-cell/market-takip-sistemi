﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MARKETTAKIPSISTEMI
{
    class Veritabani
    {
        public static SqlConnection baglanti = new SqlConnection(
            @"Server=.\SQLEXPRESS;Database=MarketDB;Trusted_Connection=True;"
        );

        public static void Baglan()
        {
            try
            {
                if (baglanti.State == System.Data.ConnectionState.Closed)
                {
                    baglanti.Open();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("BAĞLANTI HATASI: " + ex.Message);
            }
        }
    }
}
